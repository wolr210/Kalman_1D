/* ONE-DIMENSIONAL KALMAN FILTER, CONSTANT DYNAMICS MODEL 
   Made by Jay Rana on Dec 12, 2022 (jay.rana1@gmail.com)
   Equations and iteration process provided by Alex Becker via https://www.kalmanfilter.net/kalman1d_pn.html 
   MIT Open Source License 
   Please credit if used */
#ifndef KALMAN_1D_H
#define KALMAN_1D_H

#include <Arduino.h>

class Kalman_1D {
   private:
    double processNoiseVariance;            // process noise variance [q]
    double measurementUncertainty;          // squared error of measurement [r_n]
    double currentEstimate;                 // current state estimate [x_n,n]
    double predictedEstimate;               // predicted state estimate; since this is a constant dynamics model, this will equal the current estimate [x_n,n-1]
    double currentEstimateUncertainty;      // squared error of estimate [p_n,n]
    double extrapolatedEstimateUncertainty; // extrapolated squared error of estimate [p_n,n-1]
    double kalmanGain;                      // kalman gain constant to determine weights of current estimate and measurement in new estimate calculation [K_n]

   public:
    Kalman_1D(double initEstimate, double initEstimateError, double measurementError, double procNoiseVar); // initializes filter with initial estimate, estimate error, measurement error, and process noise variance

    void iterationZero(); // performs iteration 0 of the Kalman filter (sets predictedEstimate and extrapolatedEstimate)

    void iterate(double measuredData); // performs an iteration of the Kalman filter (see cpp file for details)

    double getCurrentEstimate(); // returns current state estimate

    double getCurrentEstimateUncertainty(); // returns current state estimate uncertainty

    double getExtrapolatedEstimateUncertainty(); // returns extrapolated state estimate uncertainty

    double getKalmanGain(); // returns current kalman gain constant
};

#endif
