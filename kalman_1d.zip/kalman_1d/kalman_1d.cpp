/* ONE-DIMENSIONAL KALMAN FILTER, CONSTANT DYNAMICS MODEL 
   Made by Jay Rana on Dec 12, 2022 (jay.rana1@gmail.com)
   Equations and iteration process provided by Alex Becker via https://www.kalmanfilter.net/kalman1d_pn.html 
   MIT Open Source License 
   Please credit if used */
#include "kalman_1d.h"

Kalman_1D::Kalman_1D(double initEstimate, double initEstimateError, double measurementError, double procNoiseVar) { // initializes filter with initial estimate, estimate error, measurement error, and process noise variance
  currentEstimate = initEstimate;
  currentEstimateUncertainty = initEstimateError * initEstimateError;
  measurementUncertainty = measurementError * measurementError;
  processNoiseVariance = procNoiseVar;
  iterationZero();
}

void Kalman_1D::iterationZero() { // performs iteration 0 of the Kalman filter (sets predictedEstimate and extrapolatedEstimate)
  predictedEstimate = currentEstimate;                                                 // x_1,0 = x_0,0
  extrapolatedEstimateUncertainty = currentEstimateUncertainty + processNoiseVariance; // p_1,0 = p_0,0 + q
}

void Kalman_1D::iterate(double measuredData) { // performs an iteration of the Kalman filter
  /* STEP 1 - MEASURE */
  // measuredData [z_n]

  /*STEP 2 - UPDATE */
  kalmanGain = (extrapolatedEstimateUncertainty) / (extrapolatedEstimateUncertainty + measurementUncertainty); // K_n = p_n,n-1 / (p_n,n-1 + r_n)
  currentEstimate = predictedEstimate + kalmanGain * (measuredData - predictedEstimate);                       // x_n,n = x_n,n-1 + K_n * (z_n - x_n,n-1)
  currentEstimateUncertainty = (1 - kalmanGain) * extrapolatedEstimateUncertainty;                             // p_n,n = (1 - K_n) * p_n,n-1

  /* STEP 3 - PREDICT */
  predictedEstimate = currentEstimate;                                                                         // x_n+1,n = x_n,n
  extrapolatedEstimateUncertainty = currentEstimateUncertainty + processNoiseVariance;                         // p_n+1,n = p_n,n + q
}

double Kalman_1D::getCurrentEstimate() {
  return currentEstimate;
}

double Kalman_1D::getCurrentEstimateUncertainty() {
  return currentEstimateUncertainty;
}

double Kalman_1D::getExtrapolatedEstimateUncertainty() {
  return extrapolatedEstimateUncertainty;
}

double Kalman_1D::getKalmanGain() {
  return kalmanGain;
}
